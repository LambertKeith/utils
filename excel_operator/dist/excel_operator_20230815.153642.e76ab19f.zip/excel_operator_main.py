import excel_operator.streamlit_views as views


if __name__ == '__main__':
    views.main()