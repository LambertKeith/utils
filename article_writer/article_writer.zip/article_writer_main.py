from article_writer.article_writer_views import main
from article_writer.article_writer_views2 import main
if __name__ == '__main__':
    main()