
from text_format_conversion.views import main


if __name__ == '__main__':
    main()